import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5174,
    proxy: {
      '/api': {
        target: 'https://devjeweltrack.2cqr.in',
        changeOrigin: true,
        secure: true,
      },
    },
  },
  preview: {
    port: 5174,
    proxy: {
      '/api': {
        target: 'https://devjeweltrack.2cqr.in',
        changeOrigin: true,
        secure: true,
      },
    },
  },
})
